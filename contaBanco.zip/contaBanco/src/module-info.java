/**
 * 
 */
/**
 * @author thales
 *
 */
module contaBanco {
	requires java.sql;
}