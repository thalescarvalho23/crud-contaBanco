package dao;

import java.sql.PreparedStatement;

import conexao.Conexao;
import entily.usuario;

public class usuarioDAO {

    public void cadastrarUsuario(usuario usuario) {
        String sql = "INSERT INTO USUARIO(Numconta, DONO, TIPO, SALDO) VALUES (?, ?, ?, ?)";
        PreparedStatement ps = null;

        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setInt(1, usuario.getNumConta());
            ps.setString(2, usuario.getDono());
            ps.setInt(3, usuario.getTipo()); // pontos de interrogação da inserção
            ps.setFloat(4, usuario.getSaldo());

            ps.execute();
            ps.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

}