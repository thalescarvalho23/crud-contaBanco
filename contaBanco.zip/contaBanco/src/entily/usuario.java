package entily;

import java.util.Scanner;

public class usuario {
	Scanner in = new Scanner(System.in);

	private int numConta;
	private String dono;
	private int tipo;
	private float saldo;
	private boolean status;

	public int getNumConta() {
		return numConta;
	}

	public void setNumConta(int numConta) {
		this.numConta = numConta;
	}

	public String getDono() {
		return dono;
	}

	public void setDono(String dono) {
		this.dono = dono;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	public float getSaldo() {
		return saldo;
	}

	public void setSaldo(float saldo) {
		this.saldo = saldo;

	}

	public boolean getStatus() {
		return status;
	}

	public void status(boolean status) {
		this.status = status;
	}

	public void abrirConta() {

		System.out.println("Digite o nome do Titular da Conta :");
		dono = in.nextLine();

		System.out.println("Digite 1 para conta corrente e 2 para conta poupança: ");
		tipo = in.nextInt();

		if (tipo == 1) {
			this.saldo = 50;

		} else if (tipo == 2) {
			this.saldo = 150;

		}
		System.out.println("Crie um Número para Conta até 6 números:");
		numConta = in.nextInt();

		System.out.println("");
		System.out.println("------ Dados Bancários ------");
		System.out.println("Número :" + numConta);
		System.out.println("Dono :" + this.dono);
		System.out.println("Saldo :" + this.saldo);
		System.out.println("------ Fim Dados Bancários ------");
		System.out.println("");

	}

	public void depositar(double pvalor) {

		System.out.println("");
		System.out.println("--- Realizado Deposito ---");
		System.out.println("--- Saldo Anterior ---" + this.saldo);
		this.saldo += pvalor;
		System.out.println("--- Saldo Posterior ---" + this.saldo);
		System.out.println("--- Fim do Deposito ---");
		System.out.println("");

	}

	public void Sacar(double pValor) {

		System.out.println("");
		System.out.println("-- Realizar Saque ---");
		System.out.println(" Saldo anterior: " + this.saldo);

		if (pValor <= this.saldo) { // caso tenha saldo
			this.saldo -= pValor;
			System.out.println(" Saldo posterior: " + this.saldo);
		} else { // caso não tenha saldo
			System.out.println("Saldo Insuficiente!");

		}

		System.out.println("----Fim do Saque----");
		System.out.println("");
	}

	public void fecharConta() {
		if (saldo == 0) {

			System.out.println("Conta fechada");
		}

		else {
			System.out.println("Error! Confira se a sua conta possuí saldo");
		}
	}

	public void pagarMensal() {

		System.out.println("");
		System.out.println("-- Realizar Pagamento ---");
		System.out.println(" Saldo anterior: " + this.saldo);

		if (tipo == 1) { // caso seja corrente
			this.saldo -= 12;
			System.out.println(" Saldo posterior: " + this.saldo);

		} else if (tipo == 2) { // caso seja poupanca
			this.saldo -= 20;
			System.out.println(" Saldo posterior: " + this.saldo);
		}

		System.out.println("----Fim do pagamento ----");
		System.out.println("");
	}
}
