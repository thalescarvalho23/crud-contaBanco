package entily;
import entily.usuario;
import dao.usuarioDAO;
import java.util.Scanner;

public class contaBanco {

	public static void main(String[] args) throws Exception {

		Scanner in = new Scanner(System.in);

		int opcao; // decisao
		float valor; // saldo

		usuario u = new usuario();

		do {
			System.out.println("");
			System.out.println("----- MENU -----");
			System.out.println("1)Abrir conta");
			System.out.println("2) Depositar");
			System.out.println("3) Saque");
			System.out.println("4) fechar conta");
			System.out.println("5) Pagar Mensal");
			System.out.println("0) Sair");

			System.out.println("Opção: ");
			opcao = in.nextInt();

			if (opcao == 1) {
				u.abrirConta();
				new usuarioDAO().cadastrarUsuario(u);
			} else if (opcao == 2) {

				System.out.println("Digite o Valor do Depósito: ");
				valor = in.nextFloat();
				u.depositar(valor);
				new usuarioDAO().cadastrarUsuario(u);
			} else if (opcao == 3) {
				System.out.println("Digite o Valor do Saque : ");
				valor = in.nextFloat();
				u.Sacar(valor);
				new usuarioDAO().cadastrarUsuario(u);
			} else if (opcao == 4) {
				u.fecharConta();

			}

			else if (opcao == 5) {
				u.pagarMensal();
				new usuarioDAO().cadastrarUsuario(u);
			}

			else if (opcao != 0) {
				System.out.println("Opção Inválida!");
			}
			System.out.println("");

		} while (opcao != 0);

	}

}
